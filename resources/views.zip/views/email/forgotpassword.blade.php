<html>
	<a href="{{url('resetpassword'.'/'.$user['code'])}}">{{__('messages.reset_pwd')}}</a>
</html>