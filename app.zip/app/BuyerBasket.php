<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BuyerBasket extends Model
{
    //
    protected $table = 'buyer_basket';
    protected $primaryKey = 'id';
}
